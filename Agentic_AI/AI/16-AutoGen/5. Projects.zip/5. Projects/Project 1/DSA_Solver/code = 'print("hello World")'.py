code = 'print("hello World")'


with open('solutions.py', 'w') as f:
    f.write(code)
