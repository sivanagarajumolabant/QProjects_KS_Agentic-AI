



def sum(a,b):
    return a + b

def hello_world():
    print("Hello, World! from  1.py")




if(__name__ == '__main__'):
    hello_world()



