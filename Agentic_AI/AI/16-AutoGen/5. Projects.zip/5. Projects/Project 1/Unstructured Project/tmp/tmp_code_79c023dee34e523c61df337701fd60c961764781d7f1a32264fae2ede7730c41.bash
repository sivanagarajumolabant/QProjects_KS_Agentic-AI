# Install necessary libraries
pip install -qqq pillow imageio
